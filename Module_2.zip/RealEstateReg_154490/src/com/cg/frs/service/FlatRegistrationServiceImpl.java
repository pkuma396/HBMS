package com.cg.frs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.dao.IFlatRegistrationDAO;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	IFlatRegistrationDAO FlatRegistrationDao;
	//------------------------ 1. FRS Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:registerFlat
		 - Input Parameters	:	FlatRegistrationDTO flat
		 - Return Type		:	String id
		 - Throws			:  	RegistrationException
		 - Author			:	Pankaj
		 - Creation Date	:	07/12/2018
		 - Description		:	Adding registration details
		 ********************************************************************************************************/

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws RegistrationException {
		FlatRegistrationDao=new FlatRegistrationDAO();	
		String registrationseq;
		registrationseq= FlatRegistrationDao.registerFlat(flat);
		return null;
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException {
		FlatRegistrationDao=new FlatRegistrationDAO();
		ArrayList<Integer> List=null;
		List=FlatRegistrationDao.getAllOwnerDetails();
		return null;
	}
	public void validateRegistration(FlatRegistrationDTO flat) throws RegistrationException{
		{
			String errorMessage = "";
			String name  = null;
			String mobile    = null;
			String ownerid= null;
			
			//Validating name
			name=flat.getOwnerName();
			
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			
			if(!(nameMatcher.matches()))
			{
				errorMessage+="\nDonar Name Should Be In Alphabets and minimum 3 characters long.";
				
			}

			//Validating Phone Number
			mobile=flat.getMobile();
			
			Pattern phonePattern=Pattern.compile("^[7-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(mobile);
			
			if(!(phoneMatcher.matches()))
			{
				errorMessage+="\nPhone Number Should be in 10 digit";
				
			}
			//Validating OwnerId
			ownerid=flat.getOwnerId();
			
			Pattern idPattern=Pattern.compile("^[1-9]{1,}$");
			Matcher idMatcher=phonePattern.matcher(ownerid);
			
			if(!(phoneMatcher.matches()))
			{
				errorMessage+="\nPhone Number Should be in 10 digit";
				
			}
	}

}
