package com.cg.frs.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;
import com.cg.frs.exception.RegistrationException;

public class Client {
	static Scanner sc = new Scanner(System.in);
	static IFlatRegistrationService flatRegistrationService = null;
	static FlatRegistrationServiceImpl flatRegistrationServiceImpl=null;
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) throws RegistrationException {
		PropertyConfigurator.configure("src//log4j.properties");
		FlatRegistrationDTO flatregistration=null;
    
		
		FlatRegistrationDTO ownerId = null;
		int option = 0;
		while (option !=2) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Flat Registration Service ");
			System.out.println("_______________________________\n");

			System.out.println("1.Register Flat ");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {
				
				case 1:

					while ( flatregistration== null) {
						flatregistration = populateFlatregistration();
					}

					try {
						flatRegistrationService = new FlatRegistrationServiceImpl();
						ownerId =  flatRegistrationService.registerFlat(flatregistration);

						System.out
								.println("Registration details  has been successfully registered ");
						System.out.println("Owner  ID Is: " + ownerId);

					} finally {
						ownerId = null;
						flatRegistrationService = null;
						flatregistration = null;
					}

					
					break;
				case 2registerFlat:
					System.out.print("Exit Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-2]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	private static FlatRegistrationDTO populateFlatregistration() {

		// Variables to store donor bean details
		String ownerId = null;
		String flatType = null;
		String flatarea = null;
	    String desiredrent = null;
	    String depositamount=null;
		
	    FlatRegistrationDTO flatregistration = null;

		System.out.println("Existing OwnerIDs Are:-[1,2,3]");

		System.out.println("Please Enter your owner id fro above list:");
		ownerId = sc.next();

		System.out.println("Select Flat Type (1-1BHK, 2-2BHK): ");
		flatType = sc.next();

		System.out.println("Enter Flat Area in sq. Ft.: ");
		flatarea = sc.next();

		System.out.println("Enter desired rent amount Rs: ");
		desiredrent = sc.next();
		
		System.out.println("Enter desired deposit amount Rs: ");
		depositamount = sc.next();
		return flatregistration;
		
	}	
		
	}


