package com.cg.frs.dto;

public class FlatRegistrationDTO {
	public String ownerId;
	public String ownerName;
	public String mobile;
	public String flatRegNo;
	public String flatType;
	public String flatArea;
	@Override
	public String toString() {
		return "FlatRegistrationDTO [ownerId=" + ownerId + ", ownerName=" + ownerName + ", mobile=" + mobile
				+ ", flatRegNo=" + flatRegNo + ", flatType=" + flatType + ", flatArea=" + flatArea + ", rentAmount="
				+ rentAmount + ", depositAmount=" + depositAmount + "]";
	}
	public String rentAmount;
	public String depositAmount;
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getFlatRegNo() {
		return flatRegNo;
	}
	public void setFlatRegNo(String flatRegNo) {
		this.flatRegNo = flatRegNo;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public String getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(String flatArea) {
		this.flatArea = flatArea;
	}
	public String getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(String rentAmount) {
		this.rentAmount = rentAmount;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	
	

}
