package com.cg.frs.exception;

public class RegistrationException extends Exception{

	private static final long serialVersionUID = 726264577455921591L;
	public RegistrationException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
