package com.cg.frs.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.IFlatRegistrationService;
import com.cg.frs.service.FlatRegistrationService;
import com.cg.frs.exception.RegistrationException;


public class JunitTest {
	static IFlatRegistrationService registrationservice;
    static FlatRegistrationDTO flatregistration;

	public static void setUpBeforeClass() throws Exception {
		registrationservice=null;
		flatregistration=null;
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		registrationservice = new FlatRegistrationService();
		flatregistration = new FlatRegistrationDTO ();
		flatregistration.setOwnerId("1");
		flatregistration.setOwnerName("Vaishali Srivastva");
		flatregistration.setMobile("8888108810");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		int result = registrationservice.registerFlat(flatregistration);
		assertEquals(1, result);
	}

}
