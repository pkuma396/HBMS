package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.dao.IQueryMapper;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.util.DBConnection;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	Logger logger=Logger.getRootLogger();
	public FlatRegistrationDAOImpl()
	{
	PropertyConfigurator.configure("src//log4j.properties");
	
	}

	//------------------------ 1. RFS Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	registerFlat(FlatRegistrationDTO flat)
	 - Input Parameters	:	FlatRegistrationDTO flat
	 - Return Type		:	
	 - Throws		:  	RegistrationException
	 - Author		:	Pankaj
	 - Creation Date	:	30/07/2018
	 ********************************************************************************************************/

	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws RegistrationException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String OwnerId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,flat.getOwnerId());			
			preparedStatement.setString(2,flat.getFlatType());
			preparedStatement.setString(3,flat.getFlatArea());
			preparedStatement.setString(4,flat.getRentAmount());
			preparedStatement.setString(5,flat.getDepositAmount());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(IQueryMapper.OWNERID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				OwnerId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new RegistrationException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
			}

		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new RegistrationException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new RegistrationException("Error in closing db connection");

			}
		}
		return flat;
		
		
	}
	//------------------------ 1. FRS Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	retriveAllDetails()
		 - Input Parameters	:	
		 - Return Type		:	List
		 - Throws		    :  	DonorException
		 - Author	     	:	Pankaj
		 - Creation Date	:	30/07/2018
		 - Description		:	return list
		 ********************************************************************************************************/

		public ArrayList<Integer> getAllOwnerIds() throws RegistrationException {
			
			Connection con=DBConnection.getInstance().getConnection();
			int donorCount = 0;
			
			PreparedStatement ps=null;
			ResultSet resultset = null;
			
			ArrayList<Integer> List=new ArrayList<Integer>();
			try
			{
				ps=con.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
				resultset=ps.executeQuery();
				
				while(resultset.next())
				{	
					FlatRegistrationDTO bean=new FlatRegistrationDTO();
					bean.setOwnerId(resultset.getString(1));
					bean.setOwnerName(resultset.getString(2));
					bean.setMobile(resultset.getString(3));
					List.add(bean);
					
					donorCount++;
				}			
				
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new RegistrationException("Tehnical problem occured. Refer log");
			}
			
			finally
			{
				try 
				{
					resultset.close();
					ps.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new RegistrationException("Error in closing db connection");

				}
			}
			
			if( donorCount == 0)
				return null;
			else
				return List;
		}

	

	
}
