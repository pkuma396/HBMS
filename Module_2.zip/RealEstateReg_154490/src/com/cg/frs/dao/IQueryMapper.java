package com.cg.frs.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO flat_registrtion VALUES(owner_id_sequence.NEXTVAL,?,?,?,?)";
	public static final String OWNERID_QUERY_SEQUENCE="SELECT owner_id_sequence.CURRVAL FROM DUAL";
	public static final String RETRIVE_ALL_QUERY="Select owner_id,name,mobile FROM flat_owners";
}
