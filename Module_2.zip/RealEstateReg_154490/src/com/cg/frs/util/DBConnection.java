package com.cg.frs.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import com.cg.frs.exception.RegistrationException;

public class DBConnection {

	private static Connection conn = null;
	private static DBConnection instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	/*****************************************************************************
	 * - @throws RegistrationException - Private Constructor - Desc:Loads the
	 * jdbc.properties file and Driver Class and gets the connection
	 * 
	 * @throws RegistrationException
	 ********************************************************************************/
	private DBConnection() throws RegistrationException {
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new RegistrationException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new RegistrationException(e.getMessage());
		}

	}

	/*****************************************************************
	 * - Method Name:getInstance() - Input Parameters : - Return Type :
	 * DBConnection instance - Throws : RegistrationException - Author : Pankaj -
	 * Creation Date : 30/07/2018 - Description : Singleton and Thread safe
	 * class
	 *******************************************************************/
	public static DBConnection getInstance() throws RegistrationException {
		synchronized (DBConnection.class) {
			if (instance == null) {
				instance = new DBConnection();
			}
		}
		return instance;
	}

	/****************************************************
	 * - Method Name:getConnection() - Return Type : Connection object - Author
	 * : Pankaj - Creation Date : 30/07/2018 - Description : Returns connection
	 * object
	 ****************************************************/

	public Connection getConnection() throws RegistrationException {
		try {

			conn = dataSource.getConnection();

		} catch (SQLException e) {
			throw new RegistrationException(" Database connection problem");
		}
		return conn;
	}

	/****************************************************
	 * - Method Name:loadProperties() - Return Type : Properties object - Author
	 * : Pankaj - Creation Date : 30/07/2018 - Description : Returns Properties
	 * object
	 ****************************************************/
	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "src/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	/****************************************************
	 * - Method Name:prepareDataSource() - Return Type : OracleDataSource object - Author
	 * : Pankaj - Creation Date : 09/11/2014 - Description : Returns OracleDataSource
	 * object
	 ****************************************************/
	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("dburl");
				String username = props.getProperty("system");
				String password = props.getProperty("root");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}

}
