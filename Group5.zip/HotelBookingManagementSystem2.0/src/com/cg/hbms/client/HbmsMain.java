package com.cg.hbms.client;

import java.io.InputStreamReader;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IAdminService;
import com.cg.hbms.service.IHbmsService;
import com.cg.hbms.service.IUserService;
import com.cg.hbms.service.UserServiceImpl;

public class HbmsMain {
	static User user;
	static Hotel hotel;
	static RoomDetail room;
	static BookingDetail booking;
	static Scanner scanner;
	static IUserService userService;
	static IHbmsService hbmsService;
	static IAdminService adminService;
	static Connection connection;
	static Logger logger;

	static {
		PropertyConfigurator.configure("src//log4j.properties");
		logger = Logger.getRootLogger();
	}
	
	
	
	public static void main(String[] args) throws HbmsException {
		HbmsMain main = new HbmsMain();
		hbmsService = new HbmsServiceImpl();
		userService = new UserServiceImpl();
		booking = new BookingDetail();
		user = new User();
		room = new RoomDetail();
		hotel = new Hotel();
		
		
		boolean isTrue = true;
		String choiceIndex = "-1";
		scanner = new Scanner(new InputStreamReader(System.in));
		
		while(isTrue) {
			System.out.println("=======================================");
			System.out.println("1. Login\n2. Register Now\n#. Exit\n");
			System.out.println("=======================================");
			choiceIndex = scanner.nextLine();
			
			switch (choiceIndex) {
			case "1":	main.login();
			break;	

			case "2":	main.register();
			break;
				
			case "#":	isTrue = false;
			break;
			
			default:	System.out.println("Invalid Choice, Please try again.");
				break;
			}
		}
	}
	
//#################################################################################################################//
	public void gotoAdminDash() throws HbmsException {
		adminService = new AdminServiceImpl();
		
		String choice = "";
		boolean loggedIn = true;
		
		while(loggedIn) {
			System.out.println("=======================================");
			System.out.println("1. Hotel Management\n2. Room Management\n*. Logout");
			System.out.println("=======================================");
			choice = scanner.nextLine();
			switch (choice) {
			case "1":	manageHotel();
						break;

			case "2":	manageRoom();
						break;
			
				
			case "*":	System.out.println("Successfully Logged out, Please visit again.");
						loggedIn = false;
						break;
						
			default:	System.out.println("Invalid Choice, Please try again.");
						break;
			}
		}
		
	}
	
	
	///////////////			Room Management		///////////////
	public void manageRoom() throws HbmsException {
		
		showRooms();
		room = new RoomDetail();
		System.out.println("=======================================");
		System.out.println("1. Add Room\n2. Modify Room\n3. Delete Room\n*. <- Go Back");
		System.out.println("=======================================");
		String choice = scanner.nextLine();
		switch (choice) {
		case "1":	addRoom();
					break;

		case "2":	modifyRoom();
					break;
			
		case "3":	deleteRoom();
					break;
					
		case "*":	break;
					
		default:	System.out.println("Invalid Choice, Please try again.");
					break;
		}
	}
	
	public void addRoom() throws HbmsException {
		logger.info("inside add room");
		showHotels();
		getRoomDetails();
		
		
		String isValid = hbmsService.isValidRoom(room);
		if(isValid != null || room.getPerNightRate() == null){
			System.out.println(isValid);
			return ;
		}
		
		if(isHotelIdExist(room.getHotelId()) == false){
			System.out.println("Given hotel id not exist.");
			return;
		}
		
		room = adminService.addRoom(room);
		
		if(room.getRoomId() != null)
			System.out.println("Room added successfully, room id is: "+room.getRoomId());
		else
			System.out.println("Something went wrong with the process, please try again.");
		
		
	}

	public void modifyRoom() throws HbmsException {
		logger.info("inside modify room");
		showRooms();
		System.out.println("=======================================");
		System.out.println("Enter room Id from above Rooms:");
		String roomId = scanner.nextLine();

		if(!hbmsService.isValidId(roomId)){
			System.out.println("not a valid id");
			return;
		}
		if(!isRoomIdExist(Integer.parseInt(roomId))){
			System.out.println("Given Room id not exist.");
			return;
		}
		
		getRoomDetails();
		String isValid = hbmsService.isValidRoom(room);
		if(isValid != null || room.getPerNightRate() == null){
			System.out.println(isValid);
			return ;
		}
		room.setRoomId(Integer.parseInt(roomId));
		
		
		if(adminService.modifyRoom(room))
			System.out.println("Room modified successfully");
		else
			System.out.println("Something went wrong with the process, please try again.");
	}

	public void deleteRoom() throws HbmsException {
		logger.info("inside delete room");
		System.out.println("=======================================");
		System.out.println("Enter room ID to delete room: ");
		String roomId = scanner.nextLine();
		
		if(!hbmsService.isValidId(roomId)){
			System.out.println("not a valid id");
			return;
		}
		
		if(!isRoomIdExist(Integer.parseInt(roomId))){
			System.out.println("Given Room id not exist.");
			return;
		}
		Boolean isDeleted = adminService.deleteRoom(Integer.parseInt(roomId));
		if(isDeleted)
			System.out.println("Room deleted Successfully.");
		else
			System.out.println("Something went wrong with the process, please try again.");
	}
	
	public void showRooms() throws HbmsException{
		logger.info("inside Show room");
		System.out.println("Available Rooms Are : ");
		List<RoomDetail> roomList = adminService.getRoomList();
		//System.out.println(roomList.size());
		printList(roomList);
	}
	
	public Boolean isRoomIdExist(Integer roomId) throws HbmsException{
		List<RoomDetail> roomList = adminService.getRoomList();
		
		
		if(roomList == null || roomList.isEmpty()){
			System.out.println("Sorry no data available.");
			return false;
		}
		
		Iterator<RoomDetail> iterator = roomList.iterator();
		
		while(iterator.hasNext()){
			if(iterator.next().getRoomId().equals(roomId)){
				return true;
			}
		}
		return false;
	}
	
	public void getRoomDetails(){
		
		System.out.println("Please Enter Room Details: ");
		System.out.print("Hotel ID: ");
		String hotelId = scanner.nextLine();
		System.out.print("Room Number: ");
		String roomNo = scanner.nextLine();
		System.out.print("Room Type: ");
		String roomType = scanner.nextLine();
		System.out.print("Average Rate per Night: ");
		String perNightRate = scanner.nextLine();
		System.out.print("Availability: ");
		String availability = scanner.nextLine();
		
		if(!hbmsService.isValidId(hotelId)){
			System.out.println("Not a valid hotel Id.");
			return;
		}
		
		room.setHotelId(Integer.parseInt(hotelId));
		room.setRoomNo(roomNo);
		room.setRoomType(roomType);
		
		room.setAvailability(availability);
		
		Matcher matcher = Pattern.compile("[0-9]{1,4}+[.0-9]{0,3}").matcher(perNightRate);
		if(!matcher.matches()){
			System.out.println("rate should be only digits");
			
			return;
		}
		room.setPerNightRate(Double.parseDouble(perNightRate));
	}
	
	///////////////          hotel management		//////////////
	public void manageHotel() throws HbmsException {
		
		showHotels();
		hotel = new Hotel();
		System.out.println("=======================================");
		System.out.println("1. Add Hotel\n2. Modify Hotel\n3. Delete Hotel\n*. <- Go Back");
		System.out.println("=======================================");
		String choice = scanner.nextLine();
		switch (choice) {
		case "1":	addHotel();
					break;

		case "2":	modifyHotel();
					break;
			
		case "3":	deleteHotel();
					break;
					
		case "*":	break;
					
		default:	System.out.println("Invalid Choice, Please try again.");
					break;
		}
	}
	
	public void addHotel() throws HbmsException {
		logger.info("inside add Hotel");
		getHotelDetails();
		

		String isValid = hbmsService.isValidHotel(hotel);
		if(isValid != null || hotel.getAvgRatePerNight() == null){
			System.out.println(isValid);
			return ;
		}
		
		hotel = adminService.addHotel(hotel);
		
		if(hotel.getHotelId() != null)
			System.out.println("Hotel added successfully, hotel id is: "+hotel.getHotelId());
		else
			System.out.println("Something went wrong with the process, please try again.");
	}

	public void modifyHotel() throws HbmsException {
		logger.info("inside modify hotel");
		showHotels();
		System.out.println("=======================================");
		System.out.println("Enter hotel Id from above hotels:");
		String hotelId = scanner.nextLine();
		
		if(!hbmsService.isValidId(hotelId)){
			System.out.println("not a valid id");
			return;
		}
		
		if(isHotelIdExist(Integer.parseInt(hotelId)) == false){
			System.out.println("Given hotel id not exist.");
			return;
		}
		
		hotel.setHotelId(Integer.parseInt(hotelId));
		getHotelDetails();
		

		String isValid = hbmsService.isValidHotel(hotel);
		if(isValid != null ){
			System.out.println(isValid);
			return ;
		}
		if(adminService.modifyHotel(hotel))
			System.out.println("Hotel modified successfully");
		else
			System.out.println("Something went wrong with the process, please try again.");
	}
	
	public void deleteHotel() throws HbmsException {
		logger.info("inside delete hotel");
		System.out.println("=======================================");
		System.out.println("Enter hotel ID to delete hotel: ");
		String hotelId = scanner.nextLine();
		
		if(!hbmsService.isValidId(hotelId)){
			System.out.println("not a valid id");
			return;
		}
		
		if(isHotelIdExist(Integer.parseInt(hotelId)) == false){
			System.out.println("Given hotel id not exist.");
			return;
		}
		
		Boolean result = adminService.deleteHotel(Integer.parseInt(hotelId));
		if(result)
			System.out.println("Hotel deleted Successfully.");
		else
			System.out.println("Something went wrong with the process, please try again.");
	}

	public Boolean isHotelIdExist(Integer hotelId) throws HbmsException{
		List<Hotel> hotelList = userService.getHotelList();
		Boolean result = false ;
		
		if(hotelList == null || hotelList.isEmpty()){
			System.out.println("Sorry no data available.");
			return result;
		}
		
		Iterator<Hotel> iterator = hotelList.iterator();
		
		while(iterator.hasNext()){
			Integer id = iterator.next().getHotelId();
			//System.out.println(" id : "+id+" hotel id: "+hotelId);
			if(id.equals(hotelId)){
				result = true;
				break;
			}
		}
		return result;
	}

	public void getHotelDetails() {
		System.out.println("Please Enter Hotel Details");
		System.out.println("=======================================");
		System.out.print("Hotel Name: ");
		String hotelName = scanner.nextLine();
		System.out.print("City: ");
		String city = scanner.nextLine();
		System.out.print("Address: ");
		String address = scanner.nextLine();
		System.out.print("Description: ");
		String description = scanner.nextLine();
		System.out.print("Average Rate per Night: ");
		String ratePerNight = scanner.nextLine();
		System.out.print("Phone No. 1: ");
		String phoneOne = scanner.nextLine();
		System.out.print("Phone No 2: ");
		String phoneTwo = scanner.nextLine();
		System.out.print("Rating: ");
		String rating = scanner.nextLine();
		System.out.print("Email: ");
		String email = scanner.nextLine();
		System.out.print("Fax: ");
		String fax = scanner.nextLine();
		
		
		hotel.setHotelName(hotelName);
		hotel.setCity(city);
		hotel.setAddress(address);
		hotel.setDescription(description);
		hotel.setPhoneNoOne(phoneOne);
		hotel.setPhoneNoTwo(phoneTwo);
		hotel.setRating(rating);
		hotel.setEmail(email);
		hotel.setFax(fax);
		
		Matcher matcher = Pattern.compile("[0-9]{1,4}+[.0-9]{0,3}").matcher(ratePerNight);
		if(!matcher.matches()){
			System.out.println("rate should be only digits");
			
			return;
		}
		
		hotel.setAvgRatePerNight(Double.parseDouble(ratePerNight));
	}

//#####################################################################################################################//	
//###############################################################################################################//	
	public void gotoUserDash() throws HbmsException {
		
		String choice = "";
		boolean loggedIn = true;
		
		while(loggedIn){
			System.out.println("=======================================");
			System.out.println("1. View Available Hotels\n2. View previous bookings\n3. View Rooms by hotel\n4. Book room\n*. Logout");
			System.out.println("=======================================");
			choice = scanner.nextLine();
			switch (choice) {
			case "1":	showHotels();
						break;

			case "2":	showBookings();
						break;
				
			case "3":	showRoomsByHotel();
						break;
					
			case "4":	bookRoom();
						break;
				
			case "*":	System.out.println("Successfully Logged out, Please visit again.");
						loggedIn = false;
						break;
						
			default:	System.out.println("Invalid Choice, Please try again.");
						break;
			}
		}
	}
	

	public void bookRoom() throws HbmsException {
		showRoomsByHotel();
		
		room = new RoomDetail();
		
		getBookingDetails();
		
		/*String isValid = hbmsService.isValidBooking(booking);
		if(isValid != null){
			System.out.println(isValid);
			return ;
		}*/
		calculateAmount();
		booking = userService.bookRoom(booking);
		if(booking.getBookingId() != null) {
			System.out.println("Booking successful with Booking ID: "+booking.getBookingId()+" and Amount paid is: "+booking.getAmount());
		}else {
			System.out.println("Something went wrong with the process, please try again.");
		}
	}
	
	
	public void getBookingDetails() throws HbmsException{
		System.out.println("=======================================");
		System.out.println("Please Enter Room ID: ");
		String roomId = scanner.nextLine();
		System.out.println("Enter Check in Date(dd/mm/yyyy): ");
		String from = scanner.nextLine();
		System.out.println("Enter Check out Date(dd/mm/yyyy): ");
		String to = scanner.nextLine();
		System.out.println("Enter No of Adults: ");
		String noAdults = scanner.nextLine();
		System.out.println("Enter No of Children: ");
		String noChildren = scanner.nextLine();
		// validation  ///////////////////////////////////////////	
		Date bookedFrom = null;
		Date bookedTo = null;
		try {
			bookedFrom = new SimpleDateFormat("dd/MM/yyyy").parse(from);
			bookedTo = new SimpleDateFormat("dd/MM/yyyy").parse(to);
		} catch (Exception Exception) 
		{
			logger.error("exception occured ",Exception);
			System.out.println("ERROR : " +Exception.getMessage());
		}
		//System.out.println("date from: "+bookedFrom);
		//System.out.println("date to: "+bookedTo);
		
		room.setRoomId(Integer.parseInt(roomId));
		room = userService.getRoomById(room.getRoomId());
		booking.setRoomId(room.getRoomId());
		booking.setUserId(user.getUserId());
		booking.setBookedFrom(bookedFrom);
		booking.setBookedTo(bookedTo);
		booking.setNoOfAdults(Integer.parseInt(noAdults));
		booking.setNoOfChildren(Integer.parseInt(noChildren));
		
	}

	
	public void calculateAmount() {
		logger.info("inside amount calculation");
		long diff =  booking.getBookedTo().getTime() - booking.getBookedFrom().getTime();
		Long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		Double amount = days * room.getPerNightRate();
		booking.setAmount(amount);
		System.out.println("amount: "+amount);
	}
	
	
	public void showRoomsByHotel() throws HbmsException {
		logger.info("inside showing room by hotel");
		showHotels();
		hotel = new Hotel();
		System.out.println("=======================================");
		System.out.println("Please Enter Hotel ID: ");
		String hotelId = scanner.nextLine();
		
		if(!hbmsService.isValidId(hotelId)){
			System.out.println("not a valid id");
			return;
		}
		
		hotel.setHotelId(Integer.parseInt(hotelId));
		System.out.println("Available Rooms Are: ");
		System.out.println("=======================================");
		List<RoomDetail> roomList = userService.getRoomByHotel(hotel.getHotelId());
		printList(roomList);
	}
	
	
	public void showHotels() throws HbmsException {
		
		System.out.println("Available Hotels Are : ");
		System.out.println("=======================================");
		List<Hotel> hotelList = userService.getHotelList();
		printList(hotelList);
	}
	
	
	public void showBookings() throws HbmsException {
		System.out.println("Your Booking Details Are :");
		System.out.println("=======================================");
		List<BookingDetail> bookingList = userService.getBookingByUser(user.getUserId());
		printList(bookingList);
	}
	
//#####################################################################################################################//
	public void register() throws HbmsException {
		getRegisterationDetails();
		
		String isValid = hbmsService.isValidUser(user);
		if(isValid != null){
			System.out.println(isValid);
			return ;
		}
		
		user = hbmsService.registerUser(user);
		
		if(user.getUserId() != null){
			System.out.println("registered successfully");
		}
	}
	
	public void login() throws HbmsException {
		getLoginDetails();

		String isValid = hbmsService.isValidLogin(user.getUserName(), user.getPassword());
		if(isValid != null){
			System.out.println(isValid);
			return ;
		}
		
		user = hbmsService.loginUser(user);
		
		
		if(user.getRole() == null) {
			System.out.println("Invalid Credentials !!! ");
		}else if(user.getRole().equals("admin")){
			gotoAdminDash();
		}else{
			gotoUserDash();
		}
	}
	
	public void getLoginDetails(){
		System.out.println("=======================================");
		System.out.println("Please Enter Username:");
		user.setUserName(scanner.nextLine());
		System.out.println("please Enter Password:");
		user.setPassword(scanner.nextLine());
	}
	
	public void getRegisterationDetails() {
		getLoginDetails();
				
		System.out.println("Please Enter Role:");
		user.setRole(scanner.nextLine());
		System.out.println("please Enter mobile No:");
		user.setMobileNumber(scanner.nextLine());
		System.out.println("Please Enter phone:");
		user.setPhoneNumber(scanner.nextLine());
		System.out.println("please Enter address:");
		user.setAddress(scanner.nextLine());
		System.out.println("Please Enter email:");
		user.setEmail(scanner.nextLine());
	}

	public void printList(List list) {
		System.out.println("=======================================");
		System.out.println();
		
		if(list == null || list.isEmpty()){
			System.out.println("Sorry no data available.");
			return;
		}
		
		Iterator iterator = list.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}
}
