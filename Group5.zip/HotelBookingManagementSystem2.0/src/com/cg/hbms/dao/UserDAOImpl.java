package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.util.DbConnection;

public class UserDAOImpl implements IUserDAO {
	static Connection connection;
	static Logger logger;
	
	static {
		PropertyConfigurator.configure("src//log4j.properties");
		logger = Logger.getRootLogger();
	}

	
	

	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		connection = DbConnection.getConnection();
		List<Hotel> hotelList=new ArrayList<Hotel>();
		int hotelCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.GET_HOTEL);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				Hotel hotel = new Hotel();
				hotel.setHotelId(resultSet.getInt(1));
				hotel.setCity(resultSet.getString(2));
				hotel.setHotelName(resultSet.getString(3));
				hotel.setAddress(resultSet.getString(4));
				hotel.setDescription(resultSet.getString(5));
				hotel.setAvgRatePerNight(resultSet.getDouble(6));
				hotel.setPhoneNoOne(resultSet.getString(7));
				hotel.setPhoneNoTwo(resultSet.getString(8));
				hotel.setRating(resultSet.getString(9));
				hotel.setEmail(resultSet.getString(10));
				hotel.setFax(resultSet.getString(11));
				
				hotelList.add(hotel);
				hotelCount++;
			}
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(hotelCount==0){
			return null;
		}else{
			return hotelList;
		}
	}

	
	
	
	
	@Override
	public List<RoomDetail> getRoomByHotel(Integer hotelId) throws HbmsException {
		connection = DbConnection.getConnection();
		List<RoomDetail> roomList=new ArrayList<RoomDetail>();
		int roomCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.GET_ROOM_BY_HOTEL);
			preparedStatement.setInt(1, hotelId);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				RoomDetail roomDetails = new RoomDetail();
				roomDetails.setRoomId(resultSet.getInt(1));
				roomDetails.setHotelId(resultSet.getInt(2));
				roomDetails.setRoomNo(resultSet.getString(3));
				roomDetails.setRoomType(resultSet.getString(4));
				roomDetails.setPerNightRate(resultSet.getDouble(5));
				roomDetails.setAvailability(resultSet.getString(6));
				
				roomCount++;
				roomList.add(roomDetails);
				
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(roomCount==0){
			return null;
		}else{
			return roomList;
		}
	}
		
	
	
	

	@Override
	public BookingDetail bookRoom(BookingDetail bookingDetail) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement2=null;
		ResultSet resultset = null;
		int queryResult = 0;
		Integer bookingId = -1;
		
		Date from = new Date(bookingDetail.getBookedFrom().getTime());
		Date to = new Date(bookingDetail.getBookedTo().getTime());
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.BOOK_ROOM);

			preparedStatement.setInt(1,bookingDetail.getRoomId());
			preparedStatement.setInt(2, bookingDetail.getUserId());
			preparedStatement.setDate(3,from);
			preparedStatement.setDate(4,to);
			preparedStatement.setInt(5,bookingDetail.getNoOfAdults());
			preparedStatement.setInt(6, bookingDetail.getNoOfChildren());
			preparedStatement.setDouble(7, bookingDetail.getAmount());
			
			
			queryResult=preparedStatement.executeUpdate();

			preparedStatement2=connection.prepareStatement(QueryMapper.GET_BOOKING_CURR_SEQ);
			resultset=preparedStatement2.executeQuery();


			if(resultset.next()){
			    bookingId = resultset.getInt(1);
				bookingDetail.setBookingId(bookingId);
			}
			if(queryResult==0){
				logger.error("insertion failed");
				throw new HbmsException("Inserting failed");
			}
			else{
				logger.info("successfully inserted");
				return bookingDetail;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HbmsException("technical problem.Refer to log for details");
		}
		finally{

			try {
				if(resultset != null){
					resultset.close();
				}
				if(preparedStatement != null){
					preparedStatement.close();
				}
				if(preparedStatement2!= null){
					preparedStatement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException("Error in closing the database connections");
			}
		}
	
	}


	
	
	
	@Override
	public List<BookingDetail> getBookingByUser(Integer userId) throws HbmsException {
		connection = DbConnection.getConnection();
		List<BookingDetail> bookingList=new ArrayList<BookingDetail>();
		int bookingCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.GET_BOOKING_BY_USER);
			preparedStatement.setInt(1, userId);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				BookingDetail bookingDetails = new BookingDetail();
				bookingDetails.setBookingId(resultSet.getInt(1));
				bookingDetails.setRoomId(resultSet.getInt(2));
				bookingDetails.setUserId(resultSet.getInt(3));
				bookingDetails.setBookedFrom(resultSet.getDate(4));
				bookingDetails.setBookedTo(resultSet.getDate(5));
				bookingDetails.setNoOfAdults(resultSet.getInt(6));
				bookingDetails.setNoOfChildren(resultSet.getInt(7));
				bookingDetails.setAmount(resultSet.getDouble(8));
				bookingCount++;
				
				bookingList.add(bookingDetails);
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(bookingCount==0){
			return null;
		}else{
			return bookingList;
		}
	}











	@Override
	public RoomDetail getRoomById(Integer roomId) throws HbmsException {
		connection = DbConnection.getConnection();
		RoomDetail roomDetails = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.GET_ROOM_BY_ID);
			preparedStatement.setInt(1, roomId);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()){
				roomDetails = new RoomDetail();
				roomDetails.setRoomId(resultSet.getInt(1));
				System.out.println("id: "+ resultSet.getInt(1));
				roomDetails.setHotelId(resultSet.getInt(2));
				roomDetails.setRoomNo(resultSet.getString(3));
				roomDetails.setRoomType(resultSet.getString(4));
				roomDetails.setPerNightRate(resultSet.getDouble(5));
				roomDetails.setAvailability(resultSet.getString(6));
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(roomDetails == null){
			return null;
		}else{
			return roomDetails;
		}
	}

}
