package com.cg.restdemo.controller;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/hello")
public class RestClass {
	
	@POST
	@Path("/display/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public Object display(@PathParam("name") String uname,@QueryParam("age") String age) {
		System.out.println("my name is "+uname+" "+ age);
		Object[] obj = new Object[2];
		obj[0] = uname;
		obj[1] = age;
		return obj;
	}
	
	@GET
	@Path("/sayHello")
	@Produces(MediaType.APPLICATION_JSON)
	public Object sayHello(@QueryParam("name") String eName,@QueryParam("age") String eAge) {
		System.out.println(eName+" "+eAge);
		Object[] obj = new Object[2];
		//eName ="aaa";
		obj[0] = eName;
		obj[1] = eAge;
		return obj;
	}
	
	@PUT
	@Path("/putDemo")
	public Object putDemo(@QueryParam("name") String eName,@QueryParam("age") String eAge) {
		
		Object[] obj = new Object[2];
		obj[0] = eName;
		obj[1] = eAge;
		
		System.out.println(eName+" "+eAge);
		return obj;
	}
	
	@DELETE
	@Path("/deleteDemo/{id}")
	public Object deleteDemo(@PathParam("id") String id) {

	    String eAge = "32";	
		Object[] obj = new Object[2];
		obj[0] = id;
		obj[1] = eAge;
		
		System.out.println(id+" "+eAge);
		return obj;
	}
	
}
