import { Component } from '@angular/core';
import { Employee } from './employee';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs"
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Objectives';


id;
name;
salary;
dept;
 
uid;
uname;
usalary;
udept;

deleteid;

employee = new Employee("",0,"","");
employeeList= new Array();
  index = -1;
  message;

  constructor(private http: HttpClient) {
		this.getJSON().subscribe(data => {
			for(let employee of data){
				this.employeeList.push(employee);
				console.log(employee);
			}
		});
	}

  public getJSON(): Observable<any> {
		return this.http.get("./assets/employee.json")
  }
  addEmployee(){
    console.log("id: "+this.id);
    let employee:Employee= new Employee(this.id,this.name,this.salary,this.dept);
    this.employeeList.push(employee);
    this.message="DATA INSERTED";

    this.id = "";
    this.name = "";
    this.salary = "";
    this.dept = "";

  }
  deleteEmployee(event:Event){
    var delId = ((<HTMLInputElement>event.target).name;
    this.deleteid = Number.parseInt(delId);
    this.employeeList.splice(this.deleteid, 1);
     // let ind=this.employeeList.indexOf(employee);
    //console.log("ind");
    //this.employeeList.splice(ind);
    //this.message="DATA DELETED"
  }

update(employee:Employee){
  this.index=this.employeeList.indexOf(employee);
  this.uid=employee.id;
  this.uname = employee.name;
  this.usalary = employee.salary;
  this.udept = employee.dept;
}
updateEmployee(){
    this.employee.id = this.uid;
    this.employee.name = this.uname;
    this.employee.salary = this.usalary;
    this.employee.dept = this.udept;

 this.employeeList[this.index] = this.employee;
    this.message = "DATA updated";

    this.uid = "";
    this.uname = "";
    this.usalary = "";
    this.udept = "";

  }
  public sortId(){
  this.employeeList=this.employeeList.sort((a,b) => a.id - b.id);
  }
  public sortName(event:Event){
  this.employeeList=this.employeeList.sort((a,b) => a.getName().localeCompare(b.getName()));
  }
  public sortSal(){
  this.employeeList=this.employeeList.sort((a,b) => a.salary - b.salary );
  }
  public sortDept(event:Event){
  this.employeeList=this.employeeList.sort((a,b) => a.getDept().localeCompare(b.getDept()));
  }  
  }
