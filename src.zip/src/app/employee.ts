export class Employee{
  id:Number;
  name:String;
  salary:String;
  dept:String;


   constructor(id,name,salary,dept)
   {
    this.id=id;
    this.name=name;
    this.salary=salary;
    this.dept=dept;
  }
  public setId(id){
    this.id = id;
  }
  public getId():Number{
    return this.id;
  }
  public setName(name){
    this.name = name;
  }
  public getName():String{
    return this.name;
  }
   public setSalary(salary){
    this.salary = salary;
  }
  public getSalary():String{
    return this.salary;
  }
   public setDept(dept){
    this.dept = dept;
  }
  public getDept():String{
    return this.dept;
  }
}
