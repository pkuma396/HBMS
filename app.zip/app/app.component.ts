import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Objectives';

id;
name;
salary;
dept;
 
uid;
uname;
usalary;
udept;

employee = new Employee("",0,"","");
employeeList= new Array();
  index = -1;
  message;

  addEmployee(){
    console.log("id: "+this.id);
    let employee:Employee= new Employee(this.id,this.name,this.salary,this.dept);
    this.employeeList.push(employee);
    this.message="DATA INSERTED";
  }
  deleteEmployee(employee:Employee){
    let ind=this.employeeList.indexOf(employee);
    console.log("ind");
    this.employeeList.splice(ind);
    this.message="DATA DELETED"
  }

update(employee:Employee){
  this.index=this.employeeList.indexOf(employee);
  this.uid=employee.id;
  this.uname = employee.name;
  this.usalary = employee.salary;
  this.udept = employee.dept;
}
updateEmployee(){
    this.employee.id = this.uid;
    this.employee.name = this.uname;
    this.employee.salary = this.usalary;
    this.employee.dept = this.udept;

 this.employeeList[this.index] = this.employee;
    this.message = "DATA updated";

    this.uid = "";
    this.uname = "";
    this.usalary = "";
    this.udept = "";

  }
}

class Employee{
  id;
  name;
  salary;
  dept;
   
   constructor(id,name,salary,dept)
   {
    this.id=id;
    this.name=name;
    this.salary=salary;
    this.dept=dept;
  }
}