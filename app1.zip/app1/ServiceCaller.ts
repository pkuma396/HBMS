import { Injectable, Inject } from "@angular/core";

import { HttpClient } from '@angular/common/http';
import { Emp } from  './Employee' ;
import { Observable, Subscriber, config } from "rxjs";


@ Injectable(
    {
        providedIn: 'root'

    }
)
export class Caller
{
    httpcaller;
    
    constructor(@Inject(HttpClient)http) {
        console.log("INJECTED");
        this.httpcaller=http;
    }

    getAllEmp(name,age): Observable<Object> {
        return this.httpcaller.get('http://localhost:8180/RestDemo/rest/hello/sayHello?name='+name+'&age='+age)
            .subscribe(
            (data:Object)=>{
                    console.log("SERVICE "+data);
            });
    }
    
      
    postData(name:string,age:number):Observable<String> {
        console.log("ENAME "+name);
        console.log("EAGE"+age);
        return this.httpcaller.post('http://localhost:8180/RestDemo/rest/hello/display/'+name+'?age='+age);
    }

    putDemo(name,age): Observable<Object> {
    
        return this.httpcaller.put('http://localhost:8180/RestDemo/rest/hello/putDemo?name='+name+'&age='+age)
            .subscribe(
            (data:Object)=>{
                    console.log("SERVICE "+data);
            });
    }
    
    deleteDemo(id:number):Observable<Object> {
        console.log("Eid "+id);
        return this.httpcaller.delete('http://localhost:8180/RestDemo/rest/hello/deleteDemo/'+id).subscribe((data:Object)=>{
            console.log("delete "+data);
             });
    }
    
}