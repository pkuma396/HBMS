import { BrowserModule } from '@angular/platform-browser';
import { NgModule, enableProdMode } from '@angular/core';
import { BrowserXhr } from '@angular/http';
import { AppComponent } from './app.component';
import { Caller } from './ServiceCaller';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  
  providers: [
   // {provide: BrowserXhr, useClass:CustExtBrowserXhr},
    Caller , HttpClientModule ,  HttpClient],
  bootstrap: [AppComponent ]
 
})
export class AppModule { }
