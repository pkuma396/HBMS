import { Component, Inject, Input } from '@angular/core';
import { Caller } from './ServiceCaller';
import { Emp } from  './Employee' ;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstclient';
  x;
  call;
  
  name;
  age;
  id;

  constructor(@Inject(Caller) call)
  {

    this.call=call;

  }
invokeGet(){
  console.log("COMPONENT");
  this.call.getAllEmp(this.name,this.age);
  
          
}

invokePut(){
  console.log("COMPONENT");
  this.call.putDemo(this.name,this.age);
  
          
}

invokeDelete(){
  console.log("COMPONENT "+this.id);
  this.call.deleteDemo(this.id);
  
          
}

invokePost(){
  console.log(this.name);
  this.call.postData(this.name,this.age).subscribe((data:Object)=>{
    console.log("post "+data);
     });
  
}
}
