export interface Emp
{
    msg:string;
    name:string;
    age:number;
}