package com.cg.hbms.dao;

public interface QueryMapper {

}
