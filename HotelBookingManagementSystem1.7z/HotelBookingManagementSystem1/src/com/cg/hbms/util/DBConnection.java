package com.cg.hbms.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import com.cg.hbms.exception.HbmsException;



public class DBConnection {

	private static  Connection conn=null;
	   private static DBConnection instance=null;
	   private static Properties prop=null;
	   private static OracleDataSource dataSource=null;
	   
	   /*
		 **************************************************************************************
		- Private constructor 
		- @throws StudentException 
		- Description: Loads the jdbc.properties file and Driver Class and gets the connection	
		 **************************************************************************************
		 */
	   
	   private DBConnection() throws HbmsException {
		   try {
			prop=loadProperties();
			 dataSource=prepareDataSource();
		} catch (IOException e) {
			throw new HbmsException("couldn't read database details from properties file");
		} catch (SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		  
		   
	   }
	   
	   /*
		 *****************************************************
		- Method Name		: prepareDataSource() 
		- Return Type 		: OracleDataSource object 
		- Author			: Team 5
		- Creation Date 	: /09/2018 
		- Description 		: Returns OracleDataSource object
		 *****************************************************
		 */

	private OracleDataSource prepareDataSource() throws SQLException {
		if(dataSource==null){
			if(prop!=null){
				String connectionURL=prop.getProperty("dburl");
				String username=prop.getProperty("username");
				String password=prop.getProperty("password");
				
				dataSource=new OracleDataSource();
				
				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
			
		}
		return dataSource;
	}

	/*
	 *******************************************
	- Method Name	: loadProperties() 
	- Return Type 	: Properties object 
	- Author		:Team 5
	- Creation Date : /09/2018 
	- Description	: Returns Properties object
	 *******************************************
	 */
	private Properties loadProperties() throws IOException {
		if(prop==null){
			Properties newProp= new Properties();
			String fileName="src/jdbc.properties";
			InputStream inputStream=new FileInputStream(fileName);
			newProp.load(inputStream);
			inputStream.close();
			return newProp;
			
		}
		else{
			return prop;
		}
		
		
	}
	/*
	 *******************************************
	- Method Name	: getConnection() 
	- Return Type	: Connection object 
	- Author		: Team 5
	- Creation Date : /09/2018 
	- Description 	: Returns connection object
	 *******************************************
	 */
	 
	public Connection getConnection() throws HbmsException{
		try {
			conn=dataSource.getConnection();
		} catch (SQLException e) {
			throw new HbmsException("Data Source connection problem");
		}
		return conn;
	}
	/*
	 *****************************************************
	- Method Name		: getInstance() 
	- Input Parameters	: -
	- Return Type		: DBConnection instance 
	- Throws 			: StudentException 
	- Author 			: Team 5
	- Creation Date 	: /09/2018 
	- Description 		: Singleton and Thread safe class
	 *****************************************************
	 */
	 public static DBConnection getInstance() throws HbmsException{
		 synchronized(DBConnection.class){
			 if(instance==null){
				 instance=new DBConnection();
			 }
		 }
		 return instance;
		 
	 }
	    
}
