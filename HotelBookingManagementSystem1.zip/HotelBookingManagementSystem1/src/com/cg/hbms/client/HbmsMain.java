package com.cg.hbms.client;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IHbmsService;

public class HbmsMain {

	public static void main(String[] args) throws HbmsException {
		
		IHbmsService hbmsService = new HbmsServiceImpl();
		boolean isTrue = true;
		
		while(isTrue) {
			System.out.println("1. Login\n2. Register Now");
			
		}
		

	}

}
