package com.cg.hbms.client;

public class HbmsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
