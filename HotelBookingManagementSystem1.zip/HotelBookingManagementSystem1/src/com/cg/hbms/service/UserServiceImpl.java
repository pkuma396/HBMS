package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dao.IUserDAO;
import com.cg.hbms.dao.UserDAOImpl;
import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.exception.HbmsException;

public class UserServiceImpl implements IUserService {
      IUserDAO userdao = new UserDAOImpl();
	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		return userdao.getHotelList();
	}

	@Override
	public List<RoomDetail> getRoomByHotel(Integer hotelId) throws HbmsException {
		
		return userdao.getRoomByHotel(hotelId);
	}

	@Override
	public List<BookingDetail> getBookingByUser(Integer userId) throws HbmsException {
		
		return userdao.getBookingByUser(userId);
	}

	@Override
	public BookingDetail bookRoom(BookingDetail bookingDetail) throws HbmsException {
		
		return userdao.bookRoom(bookingDetail);
	}

}
