package com.cg.hbms.service;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IHbmsService {

	public User registerUser(User user) throws HbmsException;
	public User loginUser(User user) throws HbmsException;
}
