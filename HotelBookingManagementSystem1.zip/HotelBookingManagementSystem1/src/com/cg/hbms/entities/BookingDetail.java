package com.cg.hbms.entities;

import java.util.Date;

public class BookingDetail {
	private Integer bookingId;
	private Integer roomId;
	private Integer userId;
	private Date bookedFrom;
	private Date bookedTo;
	private Integer noOfAdults;
	private Integer noOfChildren;
	private Double amount;
	
	
	
	public Integer getBookingId() {
		return bookingId;
	}



	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}



	public Integer getRoomId() {
		return roomId;
	}



	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}



	public Integer getUserId() {
		return userId;
	}



	public void setUserId(Integer userId) {
		this.userId = userId;
	}



	public Date getBookedFrom() {
		return bookedFrom;
	}



	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}



	public Date getBookedTo() {
		return bookedTo;
	}



	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}



	public Integer getNoOfAdults() {
		return noOfAdults;
	}



	public void setNoOfAdults(Integer noOfAdults) {
		this.noOfAdults = noOfAdults;
	}



	public Integer getNoOfChildren() {
		return noOfChildren;
	}



	public void setNoOfChildren(Integer noOfChildren) {
		this.noOfChildren = noOfChildren;
	}



	public Double getAmount() {
		return amount;
	}



	public void setAmount(Double amount) {
		this.amount = amount;
	}



	@Override
	public String toString() {
		return "BookingDetail [bookingId=" + bookingId + ", roomId=" + roomId
				+ ", userId=" + userId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildren=" + noOfChildren + ", amount=" + amount + "]";
	}
	
	
	
}
