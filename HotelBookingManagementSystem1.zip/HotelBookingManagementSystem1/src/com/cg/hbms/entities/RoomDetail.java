package com.cg.hbms.entities;

/*
table Details

Table Name: roomDetails

Column Names:

hotel_id		(varchar(4)),
room_id 		(varchar(4)),
room_no			(varchar(3)),
room_type		(varchar(20)),
per_night_rate	(number(6,2)),
availability	(Boolean),
photo 			(blob)

*/
public class RoomDetail {

	private Integer roomId;
	private Integer hotelId;
	private String roomNo;
	private String roomType;
	private Double perNightRate;
	private String availability;
	
	public Integer getRoomId() {
		return roomId;
	}
	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Double getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(Double perNightRate) {
		this.perNightRate = perNightRate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
	@Override
	public String toString() {
		return "RoomDetail [roomId=" + roomId + ", hotelId=" + hotelId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability +"]";
	}
	
	
	
}
