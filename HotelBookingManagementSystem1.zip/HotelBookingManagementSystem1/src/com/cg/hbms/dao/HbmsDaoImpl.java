package com.cg.hbms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.util.DBConnection;
import com.sun.corba.se.pept.transport.Connection;

public class HbmsDaoImpl implements IHbmsDao {

	@Override
	public User registerUser(User user) throws HbmsException {
		Connection connection = DBConnection.getInstance().getConnection();
		
		PreparedStatement preparedStatement =null;
		ResultSet resultSet =null;
		 
		int queryResult=0;
		try{
			preparedStatement=connection.prepareStatment(QueryMapper.REGISTER_USER);
			
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			preparedStatement.setString(3,user.getRole());
			preparedStatement.setString(4,user.getMobileNumber());
			preparedStatement.setString(5,user.getPhoneNumber());
			preparedStatement.setString(6,user.getAddress());
			preparedStatement.setString(7,user.getEmail());
			
			queryResult=preparedStatement.executeUpdate();
			
			
		}
		return null;
	}

	@Override
	public User loginUser(User user) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookingDetail> getBookingList(User user) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hotel addHotel(Hotel hotel) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hotel modifyHotel(Hotel hotel) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteHotel(Integer hotelId) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hotel getHotel(Integer hotelId) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoomDetail addRoom(RoomDetail room) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoomDetail modifyRoom(RoomDetail room) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteRoom(Integer roomId) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoomDetail getRoom(Integer roomId) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RoomDetail> getRoomList() throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookingDetail> getBookingDetails(Hotel hotel)
			throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDetail addBooking(BookingDetail booking) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteBooking(BookingDetail booking) throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

}
