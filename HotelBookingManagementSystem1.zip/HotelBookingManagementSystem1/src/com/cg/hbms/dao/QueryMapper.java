package com.cg.hbms.dao;

public interface QueryMapper {
public static final String REGISTER_USER="INSERT INTO USERS VALUES(?,?,?,?,?,?,?)";
public static final String LOGIN_USER="SELECT * FROM USERS WHERE userName=? AND upassword=?";

}
