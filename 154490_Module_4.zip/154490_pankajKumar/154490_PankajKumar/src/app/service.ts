import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {College} from './college'
import 'rxjs/Rx';

@Injectable()
export class Service {
	data:Array<Object>;
	collegeList=new Array();
    constructor(public http:Http) {
	this.http.get('/college.json')
                .subscribe(res => this.data = res.json());
	}
	
	public getCollege(){
	if(this.collegeList.length==this.data.length){
		return this.clg;
	}
		for(let i=0;i<this.data.length;i++){
		let college = new College();
		college.setcollegeId(this.data[i]['collegeId']);
		college.setcollegeName(this.data[i]['collegeName']);
		college.setState(this.data[i]['state']);
		this.collegeList.push(college);
	}
		return this.collegeList;
}
}