import { Component } from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import {CollegeService} from './login.service';
import {College} from './college'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})





export class AppComponent {
  colleges=new Array();
  collegeId;
  collegeName;
  state;
  last_id;
  deleteId;
  constructor(private newService: CollegeService) {} 
	
	 // Method called from app.component.html which show college list
	 
	public invokeCollege(){
	this.colleges=this.newService.getCollege();
	}	
	
	
 ///////// Delete A particular row of Colleges

 
 
public delete(context:Event){
  this.deleteId=parseInt((<HTMLInputElement>context.target).id);
  console.log(parseInt((<HTMLInputElement>context.target).id));
  for(let j=0;j<this.colleges.length;j++){
    if(this.colleges[j].getCollegeId()==this.deleteId){
      this.colleges.splice(j,1);
    }
}
}

////    Sorting of collegeList using Name,ID,State




sortId(){
this.colleges=this.colleges.sort((a,b)=>(a.collegeId-b.collegeId));
}
sortName(){
this.colleges=this.colleges.sort((a,b)=>(a.collegeName>b.collegeName?1:-1));
}
sortState(){
 this.colleges=this.colleges.sort((a,b)=>(a.state>b.state?1:-1));
}
}