export class College{

collegeId:number;
collegeName:string;
state:string

constructor(collegeId:number,collegeName:string,state:string) {
        this.collegeId=collegeId;
        this.collegeName=collegeName;
        this.state=state;
    }
	

	
	// getter and setters
	
	
public setCollegeId(collegeId:number){
		this.collegeId = collegeId;
	}
	public setCollegeName(collegeName:string){
		this.collegeName = collegeName;
	}
	public setState(state:string){
		this.state = state;
	}
	
	public getCollegeId(){
		return this.collegeId;
	}
	public getCollegeName(){
		return this.collegeName;
	}
	public getState(){
		return this.state;
	}
	
} 
 


