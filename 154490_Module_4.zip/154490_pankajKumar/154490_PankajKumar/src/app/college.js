"use strict";
var College = (function () {
    function College(collegeId, collegeName, state) {
        this.collegeId = collegeId;
        this.collegeName = collegeName;
        this.state = state;
    }
    // getter and setters
    College.prototype.setCollegeId = function (collegeId) {
        this.collegeId = collegeId;
    };
    College.prototype.setCollegeName = function (collegeName) {
        this.collegeName = collegeName;
    };
    College.prototype.setState = function (state) {
        this.state = state;
    };
    College.prototype.getCollegeId = function () {
        return this.collegeId;
    };
    College.prototype.getCollegeName = function () {
        return this.collegeName;
    };
    College.prototype.getState = function () {
        return this.state;
    };
    return College;
}());
exports.College = College;
//# sourceMappingURL=college.js.map