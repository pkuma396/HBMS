"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var login_service_1 = require("./login.service");
var AppComponent = (function () {
    function AppComponent(newService) {
        this.newService = newService;
        this.colleges = new Array();
    }
    // Method called from app.component.html which show college list
    AppComponent.prototype.invokeCollege = function () {
        this.colleges = this.newService.getCollege();
    };
    ///////// Delete A particular row of Colleges
    AppComponent.prototype.delete = function (context) {
        this.deleteId = parseInt(context.target.id);
        console.log(parseInt(context.target.id));
        for (var j = 0; j < this.colleges.length; j++) {
            if (this.colleges[j].getCollegeId() == this.deleteId) {
                this.colleges.splice(j, 1);
            }
        }
    };
    ////    Sorting of collegeList using Name,ID,State
    AppComponent.prototype.sortId = function () {
        this.colleges = this.colleges.sort(function (a, b) { return (a.collegeId - b.collegeId); });
    };
    AppComponent.prototype.sortName = function () {
        this.colleges = this.colleges.sort(function (a, b) { return (a.collegeName > b.collegeName ? 1 : -1); });
    };
    AppComponent.prototype.sortState = function () {
        this.colleges = this.colleges.sort(function (a, b) { return (a.state > b.state ? 1 : -1); });
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
    }),
    __metadata("design:paramtypes", [login_service_1.CollegeService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map