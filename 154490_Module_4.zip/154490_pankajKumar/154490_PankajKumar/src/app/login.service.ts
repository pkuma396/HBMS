import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {College} from './college'
import 'rxjs/Rx';

@Injectable()
export class CollegeService {
	data:Array<Object>;
	colleges=new Array();
    constructor(public http:Http) {
	this.http.get('/college.json')
                .subscribe(res => this.data = res.json());
	}
	
	
	// Get college method defined which was called in app.component.ts
	
	
	
	public getCollege(){
	if(this.colleges.length==this.data.length){
		return this.colleges;
	}
		for(let i=0;i<this.data.length;i++){
		let college=new College(this.data[i]['collegeId'], this.data[i]['collegeName'], this.data[i]['state']);
		
		this.colleges.push(college);
	}
		return this.colleges;
}
}