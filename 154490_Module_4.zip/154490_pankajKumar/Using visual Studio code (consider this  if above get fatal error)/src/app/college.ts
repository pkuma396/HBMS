export class College{
  collegeId:Number;
  collegeName:String;
  state:String;


   constructor(collegeId,collegeName,state)
   {
    this.collegeId=collegeId;
    this.collegeName=collegeName;
    this.state=state;
  }
  public setCollegeId(collegeId){
    this.collegeId = collegeId;
  }
  public getCollegeId():Number{
    return this.collegeId;
  }
  public setCollegeName(collegeName){
    this.collegeName =collegeName;
  }
  public getCollegeName():String{
    return this.collegeName;
  }
   public setState(state){
    this.state = state;
  }
  public getState():String{
    return this.state;
  }
}