import { Component } from '@angular/core';
import { College } from './college';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
   
})

export class AppComponent {
  title = "";

collegeId;
collegeName;
state;

deleteid;
college = new College("",0,"");
collegeList= new Array();
  index = -1;
  message;

  constructor(private http: HttpClient) {
		this.getJSON().subscribe(data => {
			for(let college of data){
				this.collegeList.push(college);
				console.log(college);
			}
		});
	}

  public getJSON(): Observable<any> {
		return this.http.get("./assets/college.json")
  }
   deleteCollege(event:Event){
    var delId = ((<HTMLInputElement>event.target).name);
    this.deleteid = Number.parseInt(delId);
    this.collegeList.splice(this.deleteid, 1);
   }

public sortId(){
  this.collegeList=this.collegeList.sort((a,b) => a.collegeId - b.collegeId);
  }
  public sortName(){
  this.collegeList=this.collegeList.sort((a,b) => a.collegeName>b.collegeName?1:-1);
}
public sortState(){
  this.collegeList=this.collegeList.sort((a,b) => a.state>b.state?1:-1);
  }  
}