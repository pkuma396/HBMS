import { Component } from '@angular/core';
import {booksloyee} from './booksloyee';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import {yourService} from './login.service';
import {Book} from './Book'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  books=new Array();
  id;
  title;
  year;
  author;
  update_id;
  update_title;
  update_year;
  update_author;
  last_id;
  delete_id;
  constructor(private newService: yourService) {} 
	
	public invokeMethod(){
	this.books=this.newService.getBook();
	}	
  public addBook(){
  this.books.push(new Book(this.id,this.title,this.year,this.author));
  }
public update(context:Event){
    var id=parseInt((<HTMLInputElement>context.target).id);
    for(let i=0;i<this.books.length;i++){
      if(this.books[i]!=null&& this.books[i].getId()==id)
      {this.update_id=this.books[i].getId();
        this.update_title=this.books[i].getTitle();
        this.update_year=this.books[i].getYear();
        this.update_author=this.books[i].getAuthor();
        this.last_id=this.books[i].getId();
    }
  }
  document.getElementById("div").style.display="block";
}
public updateBook(){
  for(let j=0;j<this.books.length;j++){
    if(this.books[j].getId()==this.last_id){
      this.books[j].setId(this.update_id);
      this.books[j].setTitle(this.update_title);
      this.books[j].setYear(this.update_year);
      this.books[j].setAuthor(this.update_author);

    }
  }
}
public delete(context:Event){
  this.delete_id=parseInt((<HTMLInputElement>context.target).id);
  console.log(parseInt((<HTMLInputElement>context.target).id));
  for(let j=0;j<this.books.length;j++){
    if(this.books[j].getId()==this.delete_id){
      this.books.splice(j,1);
    }
}
} 
}