"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var login_service_1 = require("./login.service");
var Book_1 = require("./Book");
var AppComponent = (function () {
    function AppComponent(newService) {
        this.newService = newService;
        this.books = new Array();
    }
    AppComponent.prototype.invokeMethod = function () {
        this.books = this.newService.getBook();
    };
    AppComponent.prototype.addBook = function () {
        this.books.push(new Book_1.Book(this.id, this.title, this.year, this.author));
    };
    AppComponent.prototype.update = function (context) {
        var id = parseInt(context.target.id);
        for (var i = 0; i < this.books.length; i++) {
            if (this.books[i] != null && this.books[i].getId() == id) {
                this.update_id = this.books[i].getId();
                this.update_title = this.books[i].getTitle();
                this.update_year = this.books[i].getYear();
                this.update_author = this.books[i].getAuthor();
                this.last_id = this.books[i].getId();
            }
        }
        document.getElementById("div").style.display = "block";
    };
    AppComponent.prototype.updateBook = function () {
        for (var j = 0; j < this.books.length; j++) {
            if (this.books[j].getId() == this.last_id) {
                this.books[j].setId(this.update_id);
                this.books[j].setTitle(this.update_title);
                this.books[j].setYear(this.update_year);
                this.books[j].setAuthor(this.update_author);
            }
        }
    };
    AppComponent.prototype.delete = function (context) {
        this.delete_id = parseInt(context.target.id);
        console.log(parseInt(context.target.id));
        for (var j = 0; j < this.books.length; j++) {
            if (this.books[j].getId() == this.delete_id) {
                this.books.splice(j, 1);
            }
        }
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
    }),
    __metadata("design:paramtypes", [login_service_1.yourService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map