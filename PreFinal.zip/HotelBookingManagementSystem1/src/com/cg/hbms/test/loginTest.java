package com.cg.hbms.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IHbmsService;

public class loginTest {
	User user;
	IHbmsService hbmsService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		user = new User();
		hbmsService = new HbmsServiceImpl(); 
		
		user.setUserName("vikas");
		user.setPassword("meena");
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws HbmsException {
		user = hbmsService.loginUser(user);
		assertNotNull(user.getUserId());
	}

}
