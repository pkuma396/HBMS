package com.cg.hbms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.hbms.dao.HbmsDaoImpl;
import com.cg.hbms.dao.IHbmsDao;
import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public class HbmsServiceImpl implements IHbmsService {

	IHbmsDao hbmsdao = new HbmsDaoImpl();
	@Override
	public User registerUser(User user) throws HbmsException {

		return hbmsdao.registerUser(user);
	}

	@Override
	public User loginUser(User user) throws HbmsException {

		return hbmsdao.loginUser(user);
	}

	////////////////////////validation of user name and password		/////////////////
	@Override
	public String isValidLogin(String username,String password){
		Pattern userPattern = Pattern.compile("[a-zA-Z]{4,20}");
		Pattern passPattern = Pattern.compile("[a-zA-Z0-9/?!@#$%^&*()_-]{5,7}");

		Matcher userMatcher = userPattern.matcher(username);
		Matcher passMatcher = passPattern.matcher(password);

		if(!userMatcher.matches()){
			return "username length should be 4 to 20, and contains alphabets only";
		}
		if(!passMatcher.matches()){
			return "password lenth should be 5 to 7";
		}
		return null;
	}

	
	public String isValidHotel(Hotel hotel) {
		// TODO Auto-generated method stub
		String errorMessage=null;
		Pattern hotelNamePattern=Pattern.compile("[A-Za-z]{4,20}");
		Pattern cityPattern=Pattern.compile("[A-Za-z]{4,10}");
		Pattern addressPattern=Pattern.compile("[A-Za-z0-9 ]{4,25}");
		Pattern descriptionPattern=Pattern.compile("[A-Za-z]{4,50}");
		Pattern phoneNoOnePattern=Pattern.compile("[7-9]{1}[0-9]{9}");
		Pattern phoneNoTwoPattern=Pattern.compile("[7-9]{1}[0-9]{9}");
		Pattern ratingPattern=Pattern.compile("[1-5]{1}");
		Pattern emailPattern=Pattern.compile("[a-z0-9._%+-]{3,7}+@[a-z0-9.-]{1,5}+.[a-z]{3}$");
		Pattern faxPattern=Pattern.compile("^?[0-9]{6,}$");
		
		Matcher hotelNameMatcher=hotelNamePattern.matcher(hotel.getHotelName());
		Matcher cityMatcher=cityPattern.matcher(hotel.getCity());
		Matcher addressMatcher=addressPattern.matcher(hotel.getAddress());
		Matcher descMatcher=descriptionPattern.matcher(hotel.getDescription());
		Matcher phoneNoOneMatcher=phoneNoOnePattern.matcher(hotel.getPhoneNoOne());
		Matcher phoneNoTwoMatcher=phoneNoTwoPattern.matcher(hotel.getPhoneNoTwo());
		Matcher ratingMatcher=ratingPattern.matcher(hotel.getRating());
		Matcher emailMatcher=emailPattern.matcher(hotel.getEmail());
		Matcher faxMatcher=faxPattern.matcher(hotel.getFax());
		
		if(!hotelNameMatcher.matches()){
			errorMessage+="Hotel Name should be alphabet only ([A to Z] or [a-z]) and a maximum of 20 characters.\n";
		} if(!cityMatcher.matches()){
			errorMessage+="City should be alphabet only ([A to Z] or [a-z]) and a maximum of 10 characters.\n";
		} if (!addressMatcher.matches()){
			errorMessage+="Address should be valid and can have maximum of 25 characters.\n";
		} if (!descMatcher.matches()){
			errorMessage+="Description should be alphabet only ([A to Z] or [a-z]) and a maximum of 50 characters.\n";
		} if (!phoneNoOneMatcher.matches()){
			errorMessage+="Enter a valid Phone Number\n";
		} if (!phoneNoTwoMatcher.matches()){
			errorMessage+="Enter a valid Phone Number\n";
		} if (!ratingMatcher.matches()){
			errorMessage+="Rating should be from 1 to 5\n";
		} if (!faxMatcher.matches()){
			errorMessage+="Enter a valid FAX";
		} if (hotel.getAvgRatePerNight()<=0||hotel.getAvgRatePerNight()>=1000000){
			errorMessage+="Average Rate Per Night cannot be negative and cannot exceed 1000000\n";
		} if (!emailMatcher.matches()){
			errorMessage+="Enter a valid email Id";
		}
		return errorMessage;
	
	}

	
	public String isValidRoom(RoomDetail room) {
		// TODO Auto-generated method stub
		String errorMessage=null;
		Pattern roomNoPattern=Pattern.compile("[1-9]{1}[0-9]{2}");
		Pattern roomTypePattern=Pattern.compile("[A-Za-z]{4,20}");
		
		Matcher roomNoMatcher=roomNoPattern.matcher(room.getRoomNo());
		Matcher roomTypeMatcher=roomTypePattern.matcher(room.getRoomType());
		
		if(!roomNoMatcher.matches()){
			errorMessage+="Room Number should be a three digit number.\n";
		} if(!roomTypeMatcher.matches()){
			errorMessage+="Enter a valid Room Type\n";
		} if(room.getAvailability()!="0"&&room.getAvailability()!="1"){
			errorMessage+="Availability can take either 1 or 0\n";
		} if(room.getPerNightRate()<=0||room.getPerNightRate()>=1000000){
			errorMessage+="Rate Per Night cannot be negative and cannot exceed 1000000\n";
		}
		
		return errorMessage;
	}

	
	public String isValidBooking(BookingDetail bookingDetails) {
		String errorMessage=null;
		Pattern bookedFromPattern=Pattern.compile("^([0-3][0-9])/(3[01]"+ "|[12][0-9]|0[1-9])/[0-9]{4}$");
		Pattern bookedToPattern=Pattern.compile("^(1[0-2]|0[1-9])/(3[01]"+ "|[12][0-9]|0[1-9])/[0-9]{4}$");
		
		
		Matcher bookedFromMatcher=bookedFromPattern.matcher(bookingDetails.getBookedFrom()+"");
		Matcher bookedToMatcher=bookedToPattern.matcher(bookingDetails.getBookedTo()+"");
		
		
		if(!bookedFromMatcher.matches()){
			errorMessage+="Date should be of form (dd/mm/yyyy)\n";
		}
		if(!bookedToMatcher.matches()){
			errorMessage+="Date should be of form (dd/mm/yyyy)\n";
		}
		if(bookingDetails.getNoOfAdults()>4||bookingDetails.getNoOfAdults()<1)
			errorMessage+="Number of Adults should be Minimum of 1 and maximum of 4\n";
		if(bookingDetails.getNoOfChildren()>2||bookingDetails.getNoOfChildren()<0)
			errorMessage+="Number of Children can be maximum of 2\n";
		if(bookingDetails.getAmount()<=0||bookingDetails.getAmount()>=1000000)
			errorMessage+="Amount cannot be negative and cannot exceed 1000000\n";
		
		
		return errorMessage;
	}
     
	    public String isValidUser(User user) {
		String errorMessage=null;
		Pattern passwordPattern=Pattern.compile("[A-Za-z0-9/?@#$%^&*()_-]{7}");
		Pattern rolePattern=Pattern.compile("[A-Za-z]{1,10}");
		Pattern usernamePattern=Pattern.compile("[A-Za-z]{1,20}");
		Pattern mobileNoPattern=Pattern.compile("[7-9]{1}[0-9]{9}");
		Pattern phoneNoPattern=Pattern.compile("[7-9]{1}[0-9]{9}");
		Pattern addressPattern=Pattern.compile("[A-Za-z]{1,25}");
		Pattern emailPattern=Pattern.compile("[a-z0-9._%+-]{3,7}+@[a-z0-9.-]{1,5}+.[a-z]{3}$");
		
		Matcher passwordMatcher=passwordPattern.matcher(user.getPassword());
		Matcher roleMatcher=rolePattern.matcher(user.getRole());
		Matcher usernameMatcher=usernamePattern.matcher(user.getUserName());
		Matcher mobileNoMatcher=mobileNoPattern.matcher(user.getMobileNumber());
		Matcher phoneNoMatcher=phoneNoPattern.matcher(user.getPhoneNumber());
		Matcher addressMatcher=addressPattern.matcher(user.getAddress());
		Matcher emailMatcher=emailPattern.matcher(user.getEmail());
		
		if(!passwordMatcher.matches()){
			errorMessage+="Enter a valid Password\n";
		} if(!roleMatcher.matches()){
			errorMessage+="Role should be either Admin or User\n";
		} if(!usernameMatcher.matches()){
			errorMessage+="Username can contain alphabet and numbers only and a maximum of 20 characters\n";
		} if(!mobileNoMatcher.matches()){
			errorMessage+="Enter a valid Mobile number\n";
		} if(!phoneNoMatcher.matches()){
			errorMessage+="Enter a valid Phone number\n";
		} if(!addressMatcher.matches()){
			errorMessage+="Address can contain alphabet and numbers only and a maximum of 25 characters\n";
		} if(!emailMatcher.matches()){
			errorMessage+="Enter a valid email id and maximum permitted length is 15 characters\n";
		}
		
		return errorMessage;
	}
}
